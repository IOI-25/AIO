
try:
    import tkinter as tk
    import requests
    import os
except ImportError as e:
    print(f"Please install {e.name}")
    exit()

window = tk.Tk()
window.title("AIO")
window.geometry("400x200")

name_var = tk.StringVar()

def install():

    global name_var

    name = name_var.get().lower().strip()
    
    optpgk='/home/makk/projects/AIO/app/opt/aio/pgk/'

    URL_DATA = f'https://raw.githubusercontent.com/IOI-25/AIO/main/pgk/{name}.tar.xz'

    response = requests.get(URL_DATA)
    
    with open(f'{optpgk}/{name}.tar.xz', 'wb') as f:
        f.write(response.content)

    os.system(f"tar -xvf {optpgk}/{name}.tar.xz -C {optpgk}")

    os.remove(f'{optpgk}/{name}.tar.xz')

Background = tk.Frame(window, bg="white")
Background.pack(fill='both', expand=True)

Name = tk.Entry(Background, textvariable=name_var)
Name.pack(fill='x', padx=10, pady=30)

Install = tk.Button(Background, text="Install", command=install)
Install.pack(fill='x', padx=10, pady=10)

window.mainloop()

